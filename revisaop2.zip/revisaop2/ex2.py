import os

def adicionar_livro(livros):
    titulo = input("Título do livro: ")
    autor = input("Autor: ")
    while True:
        try:
            ano = int(input("Ano de publicação: "))
            if ano <= 0:
                raise ValueError("Ano deve ser positivo.")
            break
        except ValueError as e:
            print("Erro:", e)
    
    while True:
        try:
            paginas = int(input("Número de páginas: "))
            if paginas <= 0:
                raise ValueError("Número de páginas deve ser positivo.")
            break
        except ValueError as e:
            print("Erro:", e)
    
    livros.append({"titulo": titulo, "autor": autor, "ano": ano, "paginas": paginas})
    print("Livro adicionado com sucesso!")

def listar_livros(livros):
    for livro in livros:
        print(f"{livro['titulo']} - {livro['autor']} - {livro['ano']} - {livro['paginas']} páginas")

def salvar_livros(livros):
    try:
        with open("biblioteca.txt", "w") as file:
            for livro in livros:
                file.write(f"{livro['titulo']},{livro['autor']},{livro['ano']},{livro['paginas']}\n")
        print("Dados salvos no arquivo 'biblioteca.txt'.")
    except Exception as e:
        print("Erro ao salvar os dados:", e)

livros = []
while True:
    print("\n1. Adicionar livro")
    print("2. Listar livros")
    print("3. Salvar dados em arquivo")
    print("4. Sair")
    opcao = input("> ")
    
    if opcao == "1":
        adicionar_livro(livros)
    elif opcao == "2":
        listar_livros(livros)
    elif opcao == "3":
        salvar_livros(livros)
    elif opcao == "4":
        break
    else:
        print("Opção inválida!")
