import os

def adicionar_aluno(alunos):
    nome = input("Nome do aluno: ")
    notas = []
    while True:
        try:
            qtd_notas = int(input("Quantas notas deseja adicionar? (2 a 5): "))
            if qtd_notas < 2 or qtd_notas > 5:
                raise ValueError("Número inválido de notas.")
            break
        except ValueError as e:
            print("Erro:", e)
    
    for i in range(qtd_notas):
        while True:
            try:
                nota = float(input(f"Nota {i + 1}: "))
                if nota < 0 or nota > 10:
                    raise ValueError("Nota deve ser entre 0 e 10.")
                notas.append(nota)
                break
            except ValueError as e:
                print("Erro:", e)
    
    media = sum(notas) / len(notas)
    alunos.append({"nome": nome, "notas": notas, "media": media})
    print("Aluno adicionado com sucesso!")

def ordenar_alunos(alunos):
    alunos.sort(key=lambda x: x["media"], reverse=True)

def salvar_em_arquivo(alunos):
    try:
        if os.path.exists("alunos.txt"):
            opcao = input("Arquivo já existe. Deseja sobrescrever? (S/N): ").strip().upper()
            if opcao != "S":
                print("Operação cancelada.")
                return
        with open("alunos.txt", "w") as file:
            for aluno in alunos:
                file.write(f"{aluno['nome']},{aluno['media']:.2f}\n")
        print("Dados salvos no arquivo 'alunos.txt'.")
    except Exception as e:
        print("Erro ao salvar os dados:", e)

alunos = []
while True:
    adicionar_aluno(alunos)
    continuar = input("Deseja adicionar outro aluno? (S/N): ").strip().upper()
    if continuar != "S":
        break

ordenar_alunos(alunos)
print("Alunos ordenados por média:")
for aluno in alunos:
    print(f"{aluno['nome']} - Média: {aluno['media']:.2f}")

salvar_em_arquivo(alunos)
