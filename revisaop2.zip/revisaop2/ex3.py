import os

def adicionar_produto(produtos):
    nome = input("Nome do produto: ")
    categoria = input("Categoria: ")
    while True:
        try:
            preco = float(input("Preço: "))
            if preco <= 0:
                raise ValueError("Preço deve ser positivo.")
            break
        except ValueError as e:
            print("Erro:", e)
    
    while True:
        try:
            quantidade = int(input("Quantidade: "))
            if quantidade < 0:
                raise ValueError("Quantidade não pode ser negativa.")
            break
        except ValueError as e:
            print("Erro:", e)
    
    produtos.append({"nome": nome, "categoria": categoria, "preco": preco, "quantidade": quantidade})
    print("Produto adicionado com sucesso!")

def listar_produtos(produtos):
    for produto in produtos:
        print(f"{produto['nome']} - {produto['categoria']} - R${produto['preco']:.2f} - {produto['quantidade']} unidades")

def salvar_estoque(produtos):
    try:
        with open("estoque.txt", "w") as file:
            for produto in produtos:
                file.write(f"{produto['nome']},{produto['categoria']},{produto['preco']},{produto['quantidade']}\n")
        print("Dados salvos no arquivo 'estoque.txt'.")
    except Exception as e:
        print("Erro ao salvar os dados:", e)

produtos = []
while True:
    print("\n1. Adicionar produto")
    print("2. Listar produtos")
    print("3. Salvar estoque em arquivo")
    print("4. Sair")
    opcao = input("> ")
    
    if opcao == "1":
        adicionar_produto(produtos)
    elif opcao == "2":
        listar_produtos(produtos)
    elif opcao == "3":
        salvar_estoque(produtos)
    elif opcao == "4":
        break
    else:
        print("Opção inválida!")
